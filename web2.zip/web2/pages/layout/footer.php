<footer class="" id="" style="padding-top: 15px; background-color: #96b9f2;">
  <div></div>
  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 text-center">
          <ul class="list-unstyled list-inline text-center">
            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-google"></i></a></li>
            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
            <li><a href="#"><i class="fa fa-github"></i></a></li>
          </ul>
          <p>&copy; Copyright 2018 All right reserved.</p>
        </div>
      </div>
    </div>
  </div>
</footer>